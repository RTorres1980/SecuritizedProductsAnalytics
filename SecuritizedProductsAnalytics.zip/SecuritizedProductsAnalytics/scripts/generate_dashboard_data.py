"""generate_dashboard_data.py
Produces CSV outputs and small charts that can be imported into Power BI.
"""
import pandas as pd
from pathlib import Path
import matplotlib.pyplot as plt

base = Path(__file__).resolve().parents[1]
data = pd.read_csv(base / 'data' / 'sample_portfolio.csv', parse_dates=['maturity'])

# Create simple metrics
data['years_to_maturity'] = (data['maturity'] - pd.Timestamp.today()).dt.days / 365.25
metrics = data.groupby(['sector','tranche']).agg(
    total_notional=('notional','sum'),
    avg_spread_bps=('spread_bps','mean'),
    avg_prepay=('prepay_rate','mean'),
    avg_price=('current_price','mean')
).reset_index()
metrics.to_csv(base / 'dashboard' / 'exports' / 'Sector_Tranche_Metrics.csv', index=False)

# Simple bar chart: notional by sector
sector = metrics.groupby('sector').agg(total_notional=('total_notional','sum')).reset_index()
plt.figure(figsize=(6,3))
plt.bar(sector['sector'], sector['total_notional'])
plt.title('Total Notional by Sector')
plt.tight_layout()
plt.savefig(base / 'dashboard' / 'exports' / 'Notional_By_Sector.png', dpi=150)
print('Dashboard data and images generated.')
