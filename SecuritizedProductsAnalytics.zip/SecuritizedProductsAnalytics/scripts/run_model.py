"""run_model.py
Simple cashflow & stress testing runner for the sample securitized portfolio.
Outputs: dashboard/exports/Portfolio_Summary.csv and Risk_Heatmap.png
"""
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt

base = Path(__file__).resolve().parents[1]
data = pd.read_csv(base / 'data' / 'sample_portfolio.csv', parse_dates=['maturity'])
prepay = pd.read_csv(base / 'data' / 'prepayment_rates.csv')

# Basic projected remaining life (years)
data['years_to_maturity'] = (data['maturity'] - pd.Timestamp.today()).dt.days / 365.25
data['expected_annual_cash'] = data['notional'] * data['coupon']

# Simple stress test: increase prepayment by 50% and widen spreads by 100 bps
data['stress_prepay'] = data['prepay_rate'] * 1.5
data['stress_spread_bps'] = data['spread_bps'] + 100

# Portfolio summary
summary = data.groupby('sector').agg({
    'notional':'sum',
    'expected_annual_cash':'sum',
    'current_price':'mean',
    'spread_bps':'mean'
}).reset_index()
summary.to_csv(base / 'dashboard' / 'exports' / 'Portfolio_Summary.csv', index=False)

# Risk heatmap (simple representation)
pivot = data.pivot_table(values='spread_bps', index='rating', columns='sector', aggfunc='mean')
plt.figure(figsize=(8,4))
plt.imshow(pivot.fillna(0), aspect='auto')
plt.title('Average Spread (bps) by Rating & Sector')
plt.xticks(range(len(pivot.columns)), pivot.columns, rotation=45)
plt.yticks(range(len(pivot.index)), pivot.index)
plt.colorbar(label='Spread (bps)')
plt.tight_layout()
plt.savefig(base / 'dashboard' / 'exports' / 'Risk_Heatmap.png', dpi=150)
print('Run complete. Outputs saved to dashboard/exports')
