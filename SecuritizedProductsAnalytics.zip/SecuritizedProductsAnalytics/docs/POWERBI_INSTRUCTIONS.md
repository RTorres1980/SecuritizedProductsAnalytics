POWER BI INSTRUCTIONS
---------------------
1. Open Power BI Desktop.
2. Import the CSV files from `dashboard/exports/` (Portfolio_Summary.csv, Sector_Tranche_Metrics.csv).
3. Add the PNG exports (Risk_Heatmap.png, Notional_By_Sector.png) as images or use CSVs to recreate visuals.
4. Build dashboards: Collateral Breakdown, Stress Test Comparison, Risk Heatmap, Portfolio Summary.
5. Save as `PowerBI_Dashboard.pbix` locally and publish to Power BI service if desired.
